type GateEnv = { PLAYBOOK_PASSWORD_HASH?: string; PLAYBOOK_COOKIE_KEY?: string };
const cookieName = "cis_access";
const ttl = 60 * 60 * 24;
const enc = new TextEncoder();
const hex = (a: ArrayBuffer) => Array.from(new Uint8Array(a), b => b.toString(16).padStart(2, "0")).join("");
export const digest = async (s: string) => hex(await crypto.subtle.digest("SHA-256", enc.encode(s)));
async function sign(s: string, key: string) {
  const k = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", k, enc.encode(s)));
}
function equal(a: string, b: string) { let diff = a.length ^ b.length; for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0); return diff === 0; }
const safe = (s: string | null) => { try { const u = new URL(s || "/", "https://gate.invalid"); return u.origin === "https://gate.invalid" && !["/entrada", "/sair"].includes(u.pathname) ? u.pathname + u.search : "/"; } catch { return "/"; } };
const escape = (s: string) => s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
const headers = { "Cache-Control": "private, no-store", "X-Robots-Tag": "noindex, nofollow", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "same-origin" };
function screen(next: string, error = "", status = 200) {
  return new Response(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Acesso ao CIS Roleplay</title><link rel="icon" href="/favicon.svg"><style>*{box-sizing:border-box}body{margin:0;min-height:100dvh;display:grid;place-items:center;background:#080808;color:#f5f1e7;font-family:Arial,sans-serif;font-size:1rem;line-height:1.6;padding:24px}main{width:min(100%,440px);overflow-wrap:anywhere}img{width:min(100%,320px);height:auto;margin-bottom:42px}small{color:#d7b768;letter-spacing:.12em;text-transform:uppercase;font-size:.8125rem}h1{font-size:clamp(1.75rem,6vw,2.25rem);line-height:1.15;margin:16px 0}p{color:#c9c4b9;line-height:1.6}label{display:block;margin:30px 0 10px}input,button{font:inherit;width:100%;min-height:52px;border-radius:8px}input{background:#191919;color:white;border:1px solid #71654c;padding:14px}input:focus,button:focus-visible{outline:3px solid #e4c77d;outline-offset:3px}button{background:#d7b768;color:#111;border:0;font-weight:700;cursor:pointer;margin-top:16px}.error{color:#f1b7ad;min-height:24px;font-size:.875rem}footer{margin-top:32px;color:#a59e90;font-size:.8125rem}</style></head><body><main><img src="/logo-header.svg" alt="Playbook CIS — Marcos Esteves"><small>Acesso reservado</small><h1>Seu próximo passo começa pela escuta.</h1><p>Informe a senha compartilhada para acessar o simulador e praticar suas abordagens.</p><form method="post" action="/entrada"><input type="hidden" name="next" value="${escape(next)}"><label for="password">Senha de acesso</label><input id="password" name="password" type="password" autocomplete="current-password" required maxlength="128" aria-describedby="error"><button type="submit">Entrar no simulador</button><p id="error" class="error" role="alert">${escape(error)}</p></form><footer>Marcos Esteves · Diagnóstico consultivo</footer></main></body></html>`, { status, headers: { ...headers, "Content-Type": "text/html; charset=utf-8", "Content-Security-Policy": "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'self'; base-uri 'none'" } });
}
export async function passwordGate(request: Request, env: GateEnv): Promise<Response | null> {
  const url = new URL(request.url), path = url.pathname;
  if (["/logo-header.svg", "/favicon.svg", "/favicon-32.png", "/apple-touch-icon.png"].includes(path) && ["GET", "HEAD"].includes(request.method)) return null;
  if (!/^[a-f0-9]{64}$/.test(env.PLAYBOOK_PASSWORD_HASH || "") || (env.PLAYBOOK_COOKIE_KEY?.length || 0) < 32) return screen("/", "O acesso está sendo configurado. Tente novamente em breve.", 503);
  const cookie = request.headers.get("cookie")?.split(";").map(s => s.trim()).find(s => s.startsWith(cookieName + "="))?.slice(cookieName.length + 1) || "";
  const [expiry, mac] = cookie.split(".");
  const valid = /^\d{10}$/.test(expiry || "") && Number(expiry) > Date.now() / 1000 && Number(expiry) <= Date.now() / 1000 + ttl + 60 && equal(mac || "", await sign(expiry, env.PLAYBOOK_COOKIE_KEY!));
  const cookieOptions = `Path=/; HttpOnly; SameSite=Lax${url.protocol === "https:" ? "; Secure" : ""}`;
  if (path === "/sair") {
    if (request.method !== "POST" || request.headers.get("origin") !== url.origin) return new Response("Acesso negado", { status: 403, headers });
    return new Response(null, { status: 303, headers: { ...headers, Location: "/entrada", "Set-Cookie": `${cookieName}=; Max-Age=0; ${cookieOptions}` } });
  }
  if (path === "/entrada") {
    const next = safe(url.searchParams.get("next"));
    if (request.method === "GET") return valid ? new Response(null, { status: 303, headers: { ...headers, Location: next } }) : screen(next);
    if (request.method !== "POST") return new Response("Método não permitido", { status: 405, headers });
    if (request.headers.get("origin") !== url.origin) return new Response("Acesso negado", { status: 403, headers });
    if (Number(request.headers.get("content-length") || 0) > 2048) return new Response("Requisição inválida", { status: 413, headers });
    const body = await request.text(); if (body.length > 2048) return new Response("Requisição inválida", { status: 413, headers });
    const data = new URLSearchParams(body), password = data.get("password") || "", returnTo = safe(data.get("next"));
    if (password.length > 128 || !equal(await digest(password), env.PLAYBOOK_PASSWORD_HASH!)) return screen(returnTo, "Senha incorreta. Confira e tente novamente.", 401);
    const expires = String(Math.floor(Date.now() / 1000) + ttl), token = `${expires}.${await sign(expires, env.PLAYBOOK_COOKIE_KEY!)}`;
    return new Response(null, { status: 303, headers: { ...headers, Location: returnTo, "Set-Cookie": `${cookieName}=${token}; Max-Age=${ttl}; ${cookieOptions}` } });
  }
  if (valid) return null;
  if (path.startsWith("/api/") || !["GET", "HEAD"].includes(request.method)) return new Response(JSON.stringify({ error: "Informe a senha para acessar." }), { status: 401, headers: { ...headers, "Content-Type": "application/json" } });
  return new Response(null, { status: 303, headers: { ...headers, Location: `/entrada?next=${encodeURIComponent(safe(path + url.search))}` } });
}
