export const scenarios = [
{id:"carreira", title:"Carreira estagnada", category:"Diagnóstico", page:10, brief:"Uma pessoa sente que travou profissionalmente. Descubra o que isso significa antes de apresentar o CIS.", opening:"Eu sinto que poderia estar muito melhor profissionalmente, mas parece que eu travei."},
{id:"financeiro", title:"Ganha, mas nunca sobra", category:"Diagnóstico", page:12, brief:"Investigue o padrão por trás da frustração financeira, sem julgar as escolhas do lead.", opening:"Eu ganho bem, mas meu dinheiro some. Isso me dá muita frustração."},
{id:"relacao", title:"O casamento virou uma empresa", category:"Diagnóstico", page:13, brief:"Explore o significado da expressão e o que a pessoa deseja reconstruir.", opening:"Meu casamento virou uma empresa. A gente só fala de conta e problema."},
{id:"emocional", title:"Medo de decidir", category:"Diagnóstico", page:14, brief:"Transforme uma fala ampla em uma situação concreta, sem usar rótulos clínicos.", opening:"Meu emocional está uma bagunça. Eu não consigo decidir nada."},
{id:"empresa", title:"Tudo depende de mim", category:"Diagnóstico", page:15, brief:"Entenda o gargalo, os impactos e o valor de uma mudança para o empresário.", opening:"Minha empresa até vende, mas eu trabalho demais e não consigo crescer."},
{id:"tempo", title:"Sempre por último", category:"Diagnóstico", page:16, brief:"Descubra as demandas reais da rotina e o que acaba ficando para trás.", opening:"Meu problema é que eu não tenho tempo para nada."},
{id:"preco", title:"Está caro", category:"Objeções", page:18, brief:"Acolha e investigue se a barreira é orçamento, percepção de valor ou outra dúvida.", opening:"Gostei, mas está caro para mim."},
{id:"pensar", title:"Vou pensar", category:"Objeções", page:18, brief:"Ajude o lead a explicar o que ainda precisa entender para decidir com segurança.", opening:"Vou pensar melhor e depois te falo."},
{id:"parceiro", title:"Decisão em conjunto", category:"Objeções", page:19, brief:"Respeite a decisão conjunta e descubra quais informações precisam ficar claras.", opening:"Eu preciso conversar com meu marido antes."},
{id:"cursos", title:"Já fiz outros treinamentos", category:"Objeções", page:20, brief:"Entenda a experiência anterior e o critério de confiança, sem atacar outros cursos.", opening:"Já fiz vários cursos e não mudou muita coisa."},
{id:"exposicao", title:"Medo de me expor", category:"FAQ CIS", page:34, brief:"Investigue o que a pessoa imagina sobre exposição. Não prometa ausência de desconforto.", opening:"Tenho medo de me expor."},
{id:"funciona", title:"Será que é para mim?", category:"FAQ CIS", page:34, brief:"Descubra a dúvida específica e conecte a proposta à necessidade, sem garantir resultado.", opening:"Será que funciona para mim?"}
] as const;
export type ScenarioId = typeof scenarios[number]["id"];
export type Message = {role:"user"|"assistant";content:string};
export type Feedback = {summary:string;strength:string;adjustment:string;nextQuestion:string;criteria:{criterion:string;status:"observado"|"ajustar"|"nao_observado";comment:string;page:number;sourceQuote:string;userQuote:string}[]};
