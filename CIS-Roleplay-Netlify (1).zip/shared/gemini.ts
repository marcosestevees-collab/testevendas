// Integração Gemini Developer API. A chave é enviada apenas pelo servidor, em header.
export const DEFAULT_GEMINI_MODEL='gemini-3.8-flash';
export async function generateJSON(options:{key:string;model:string;instructions:string;input:unknown;schema:unknown;maxTokens:number;timeout:number;send?:typeof fetch}):Promise<Record<string,unknown>>{
 const {key,model,instructions,input,schema,maxTokens,timeout}=options;
 if(!/^gemini-[a-z0-9.-]+$/.test(model))throw Error('MODEL');
 const thinkingConfig=model.startsWith('gemini-3')?{thinkingLevel:'LOW'}:model.startsWith('gemini-2.5')?{thinkingBudget:0}:undefined;
 const r=await (options.send||fetch)(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',headers:{'x-goog-api-key':key.trim(),'Content-Type':'application/json'},signal:AbortSignal.timeout(timeout),body:JSON.stringify({systemInstruction:{parts:[{text:instructions}]},contents:[{role:'user',parts:[{text:JSON.stringify(input)}]}],generationConfig:{responseMimeType:'application/json',responseJsonSchema:schema,maxOutputTokens:maxTokens,...(thinkingConfig?{thinkingConfig}:{})}})});
 if(!r.ok){
  let reason='';try{const e=await r.json() as {error?:{details?:{reason?:string}[]}};reason=e.error?.details?.map(d=>d.reason||'').join('|')||'';}catch{}
  if(r.status===401||r.status===403||/API_KEY_(INVALID|EXPIRED|SERVICE_BLOCKED|HTTP_REFERRER_BLOCKED|IP_ADDRESS_BLOCKED|ANDROID_APP_BLOCKED|IOS_APP_BLOCKED)/.test(reason))throw Error('KEY');
  throw Error(r.status===429?'RATE':r.status===404?'MODEL':r.status===400?'CONFIG':'PROVIDER');
 }
 let result:{promptFeedback?:{blockReason?:string};candidates?:{finishReason?:string;content?:{parts?:{text?:string;thought?:boolean}[]}}[]};try{result=await r.json();}catch{throw Error('OUTPUT');}
 if(result.promptFeedback?.blockReason)throw Error('BLOCKED');
 const candidate=result.candidates?.[0];if(candidate?.finishReason!=='STOP')throw Error(candidate?.finishReason==='SAFETY'?'BLOCKED':'OUTPUT');
 const text=candidate.content?.parts?.filter(p=>!p.thought&&typeof p.text==='string').map(p=>p.text).join('')||'';
 try{const data=JSON.parse(text);if(!data||typeof data!=='object'||Array.isArray(data))throw Error();return data;}catch{throw Error('OUTPUT');}
}
