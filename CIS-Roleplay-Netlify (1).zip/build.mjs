import {build} from 'vite';import fs from 'node:fs/promises';
await build({build:{ssr:'src/prerender.tsx',outDir:'.render',rollupOptions:{input:'src/prerender.tsx'}}});const {render}=await import('./.render/prerender.js');
const template=await fs.readFile('index.template.html','utf8');await fs.writeFile('index.html',template.replace('<!--APP-->',render()));await build();
await fs.mkdir('publish',{recursive:true});await fs.copyFile('fallback.html','publish/index.html');
