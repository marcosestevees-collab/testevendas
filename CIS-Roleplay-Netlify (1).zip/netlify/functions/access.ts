import {DEFAULT_GEMINI_MODEL} from '../../shared/gemini';
import {getStore} from '@netlify/blobs';
import {reserveProfile,profileAt,sealSession,openSession,openingKey,type Registry} from '../../shared/profiles';
import {readFile} from 'node:fs/promises';import {resolve,sep} from 'node:path';import {passwordGate,digest} from '../../shared/gate';import {validateInput,runRoleplay,generateOpening} from '../../shared/roleplay';
const limits=new Map<string,{count:number;until:number}>();
const security={"Cache-Control":"private, no-store","Netlify-CDN-Cache-Control":"no-store","X-Robots-Tag":"noindex, nofollow","X-Content-Type-Options":"nosniff","Referrer-Policy":"same-origin","Content-Security-Policy":"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'"};
const json=(d:unknown,status=200)=>Response.json(d,{status,headers:security});
export function createHandler(options:{environment?:Record<string,string|undefined>;root?:string;send?:typeof fetch;store?:()=>Registry}={}){
const environment=options.environment||process.env,root=resolve(options.root||resolve(process.cwd(),'private-site'));
return async function(request:Request,context:{ip?:string}={}){
 const url=new URL(request.url),path=url.pathname;
 try{
 const denied=await passwordGate(request,{PLAYBOOK_PASSWORD_HASH:environment.PLAYBOOK_PASSWORD?await digest(environment.PLAYBOOK_PASSWORD):undefined,PLAYBOOK_COOKIE_KEY:environment.PLAYBOOK_COOKIE_KEY});if(denied){const headers=new Headers(denied.headers);headers.set('Netlify-CDN-Cache-Control','no-store');return new Response(denied.body,{status:denied.status,headers});}
 if(path==='/api/status'){if(request.method!=='GET')return json({error:'Método não permitido.'},405);return json({connected:Boolean(environment.GEMINI_API_KEY?.trim())});}
 if(path==='/api/roleplay'){
  if(request.method!=='POST')return json({error:'Método não permitido.'},405);
  if(request.headers.get('origin')!==url.origin)return json({error:'Origem não permitida.'},403);
  if(!environment.GEMINI_API_KEY?.trim())return json({error:'A IA ainda precisa ser conectada. Seu treino não foi enviado.',code:'NOT_CONFIGURED'},503);
  if(Number(request.headers.get('content-length')||0)>120000)return json({error:'Conversa muito longa.'},413);
  const binding=await digest((request.headers.get('cookie')||'').split(';').map(c=>c.trim()).find(c=>c.startsWith('cis_access='))||'');
  let data:Record<string,unknown>,input:ReturnType<typeof validateInput>|undefined,session:ReturnType<typeof openSession>|undefined;
  try{const body=await request.text();if(body.length>120000)return json({error:'Conversa muito longa.'},413);data=JSON.parse(body);if(!data||typeof data!=='object')throw Error();
   if(data.action==='start'){if(typeof data.scenario!=='string'||(data.scenario!=='auto'&&!profileAt(0,data.scenario))||!['natural','reservado'].includes(String(data.difficulty)))throw Error();}
   else{session=openSession(data.session,environment.PLAYBOOK_COOKIE_KEY!,binding);input=validateInput(data,session);}
  }catch(e){return json({error:e instanceof Error&&e.message==='SESSION'?'Este treino expirou ou é inválido. Encerre e inicie um novo lead.':'Confira o cenário e a mensagem. Limite: 24 respostas e 2.000 caracteres por mensagem.'},400);}
  const id=await digest((context.ip||'unknown')+'|'+(request.headers.get('cookie')||'')),now=Date.now(),limit=limits.get(id);
  if(limit&&limit.until>now&&limit.count>=8)return json({error:'Aguarde um minuto antes de enviar novamente.'},429);
  if(limits.size>1000)for(const [key,value] of limits)if(value.until<now)limits.delete(key);
  limits.set(id,limit&&limit.until>now?{...limit,count:limit.count+1}:{count:1,until:now+60000});
  try{
   const model=environment.GEMINI_MODEL?.trim()||DEFAULT_GEMINI_MODEL;
   if(data.action==='start'){
    let store:Registry,index:number;try{store=options.store?options.store():getStore({name:'cis-roleplay-profiles',consistency:'strong'});index=await reserveProfile(store);}catch(e){if(e instanceof Error&&e.message==='EXHAUSTED')throw e;throw Error('REGISTRY');}
    const profile=profileAt(index,String(data.scenario));let opening='';
    for(let attempt=0;attempt<2;attempt++){opening=await generateOpening(profile,String(data.difficulty),environment.GEMINI_API_KEY,model,options.send,attempt);let saved;try{saved=await store.setJSON(openingKey(opening),{created:Date.now()},{onlyIfNew:true});}catch{throw Error('REGISTRY');}if(saved.modified)break;opening='';}
    if(!opening)throw Error('DUPLICATE');
    const token=sealSession({index,scenario:profile.scenario,difficulty:String(data.difficulty),opening,expires:Date.now()+86400000,binding},environment.PLAYBOOK_COOKIE_KEY!);
    return json({session:token,opening,scenario:profile.scenario,lead:{name:profile.name,city:profile.city,state:profile.state,occupation:profile.occupation,age:profile.age}});
   }
   return json(await runRoleplay(input!,environment.GEMINI_API_KEY,model,options.send,profileAt(session!.index,session!.scenario)));
  }catch(e){const code=e instanceof Error?e.message:'';return json({error:code==='REGISTRY'?'Não foi possível registrar um perfil novo. Confira a disponibilidade do Netlify Blobs e tente novamente.':code==='EXHAUSTED'?'O banco de perfis chegou ao limite. O responsável precisa ampliar as combinações antes de novos treinos.':code==='DUPLICATE'?'A abertura gerada já foi usada. Tente gerar outro lead; esta fala não será repetida.':code==='MODEL'?'O modelo Gemini configurado está inválido ou indisponível para este projeto. Confira GEMINI_MODEL na Netlify.':code==='CONFIG'?'O Gemini rejeitou a configuração da chamada. Confira o modelo, a disponibilidade da API e a versão publicada.':code==='BLOCKED'?'O Gemini bloqueou esta resposta. Use uma situação fictícia sem dados sensíveis e tente novamente.':code==='RATE'?'O limite de uso do Gemini foi atingido. Confira a cota ou o faturamento no Google AI Studio e tente novamente.':code==='KEY'?'A chave Gemini ou sua permissão precisa ser revisada. Confira GEMINI_API_KEY e as restrições no projeto Google.':code==='OUTPUT'?'A resposta gerada não passou pela conferência de formato ou referências. Tente novamente.':'Não foi possível obter a resposta. Sua mensagem foi preservada; tente novamente.'},502);}
 }
 if(path.startsWith('/api/'))return json({error:'Página não encontrada.'},404);
 if(!['GET','HEAD'].includes(request.method))return json({error:'Método não permitido.'},405);
 let decoded;try{decoded=decodeURIComponent(path);}catch{return json({error:'Endereço inválido.'},400);}
 if(decoded.includes('\0')||decoded.includes('\\'))return json({error:'Endereço inválido.'},400);
 const relative=decoded==='/'?'index.html':decoded.replace(/^\/+/,''),file=resolve(root,relative);
 if(!file.startsWith(root+sep))return json({error:'Acesso negado.'},403);
 const extension=file.split('.').at(-1)||'',types:Record<string,string>={html:'text/html; charset=utf-8',js:'text/javascript; charset=utf-8',css:'text/css; charset=utf-8',svg:'image/svg+xml',png:'image/png',webp:'image/webp',ico:'image/x-icon',woff2:'font/woff2'};
 if(!types[extension])return json({error:'Página não encontrada.'},404);
 try{const bytes=await readFile(file);return new Response(request.method==='HEAD'?null:bytes,{headers:{...security,'Content-Type':types[extension]}});}catch{return json({error:'Página não encontrada.'},404);}
 }catch{return json({error:'Não foi possível abrir a plataforma. Confira a publicação e as variáveis de ambiente.'},503);}
};}
export default createHandler();
export const config={path:'/*',preferStatic:false};
