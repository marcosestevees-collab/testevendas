# Revisão do CIS Roleplay — 07/10/2026

## Alterações entregues

- Tipografia legível em unidades relativas, textos auxiliares com no mínimo 0,8125rem e campos de texto/seleção com 1rem.
- Ajustes para três colunas em telas amplas, duas colunas intermediárias e coluna única em telas pequenas. Os pontos de mudança em rem respondem à ampliação da fonte.
- Quebra de títulos, mensagens longas, metadados, botões e avisos; cabeçalho e ações podem ocupar várias linhas.
- Controles com altura mínima de 44px, foco visível, ligação entre rótulos e campos, link para pular à conversa, aviso de resposta em andamento e erros acessíveis.
- Contraste das 14 combinações principais de texto verificado por cálculo de luminância: de 5,54:1 a 17,76:1; todas acima de 4,5:1. Componentes desabilitados e bordas decorativas não fazem parte dessa medição.
- Respeito à preferência de movimento reduzido. O teclado do celular não abre automaticamente ao gerar um lead. Em dispositivos de toque, Enter insere uma linha e o botão Enviar submete a mensagem.
- Timeout com mensagem amigável; o texto digitado é mantido após falha. Senha e APIs continuam protegidas no servidor.
- Nova geração de leads com cidade/UF, contexto, dor e desejo próprios. O modo Surpreenda-me alterna os 12 temas; um tema específico também recebe novos perfis.

## Testes concluídos

- TypeScript sem erros e build de produção concluído.
- APIs e arquivos privados negam acesso sem a senha; configuração ausente bloqueia a entrada.
- Senha incorreta, assinatura de cookie adulterada, saída, origem externa e arquivos não permitidos.
- Resposta e avaliação com provedor substituído por fixtures; formato de requisição da Gemini API (generateContent) e corpus integral presente nas instruções do servidor.
- Referências inventadas são recusadas; citações do consultor precisam aparecer na conversa.
- Geração de perfil e abertura; sessões inválidas, adulteradas, desvinculadas do acesso ou expiradas são recusadas.
- Falas iniciais repetidas são recusadas, sem apresentá-las como um novo lead.
- 100.000 perfis verificados sem duplicar a combinação completa, cobertura das 27 UFs, reservas simultâneas sem repetir índices e continuidade do contador entre chamadas.
- Falha do registro bloqueia a geração; ausência de ETag impede sobrescrever o contador sem proteção contra concorrência.
- Compilação pública sem corpus completo, chave Gemini ou lógica de perfis ocultos. A pasta publish contém apenas o aviso seguro de publicação incompleta.

## Responsividade: alcance da revisão

Foi feita uma revisão estrutural do CSS para larguras de referência de 320, 360, 390, 414, 768, 1024, 1366, 1440, 1920 e 2560px, incluindo a adaptação dos pontos de mudança à fonte ampliada. Esta é uma revisão de código, não uma medição visual executada em cada largura.

A prévia não ficou acessível no navegador do ambiente de revisão. Portanto, os estados de chat, erros e avaliação foram verificados na integração, mas NÃO foram certificados visualmente nesta versão. Aparelhos físicos, teclado virtual, Safari/iOS, Firefox, rotação da tela e zoom do navegador permanecem pendentes de conferência após publicar. Não houve acesso à conta Netlify nem uma chave Gemini real disponível.

## Conferência após a publicação

1. Configure as três variáveis secretas (GEMINI_API_KEY, PLAYBOOK_PASSWORD e PLAYBOOK_COOKIE_KEY) descritas em LEIA-ME.md e publique por Git ou CLI, com publish como pasta pública.
2. Confirme a função access e gere um lead. Verifique o store cis-roleplay-profiles em Data & Storage > Blobs. Não apague o contador nem o store.
3. Em celular, abra um treino, leia a fala inicial, digite, envie, peça orientação e encerre. Confira ausência de cortes, rolagem do chat e acesso aos botões com o teclado aberto.
4. Repita em desktop e tablet, com texto ampliado a 200%, mensagem longa e detalhes da avaliação abertos.
5. Gere pelo menos três treinos consecutivos em Surpreenda-me. Confira novos perfis e, ao investigar, contextos, dores e desejos consistentes dentro de cada conversa.
6. Teste uma janela anônima sem senha, senha incorreta, saída, falha da IA e preservação da mensagem.

## Limites da variedade

O registro persistente evita reutilizar o perfil completo dentro da capacidade do banco v1, desde que permaneça intacto no mesmo projeto Netlify. Cidades, temas e características individuais podem voltar em outras combinações. O bloqueio de falas iniciais detecta igualdade normalizada, não toda semelhança de significado. As respostas da IA ainda exigem julgamento humano; a plataforma não promete variedade infinita, interpretação infalível ou resultados comerciais.

## Atualização para Gemini

- Integração direta no servidor com Gemini Developer API, header x-goog-api-key e modelo configurável em GEMINI_MODEL.
- Padrão gemini-3.8-flash, conforme documentação oficial consultada. A geração usa instrução de sistema com todo o corpus e schema JSON para abertura, resposta e feedback.
- Testes com fixtures para geração de abertura, respostas, avaliação, formato de chamada Gemini, proteção da chave, exclusão de pensamentos internos e rejeição de respostas incompletas, bloqueadas ou sem JSON válido.
- Classificação de erros de chave/permissão (incluindo API_KEY_INVALID em HTTP 400), modelo ausente, configuração rejeitada, cota e indisponibilidade do serviço.
- Compilação e checagem de tipos concluídas. Não foi feita chamada com uma chave Gemini real nem publicação na conta do usuário. A confirmação com a chave e o projeto Google do responsável continua necessária após o deploy.
