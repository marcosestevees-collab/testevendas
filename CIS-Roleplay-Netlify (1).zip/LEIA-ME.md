# CIS Roleplay — Gemini / Netlify

Plataforma de treino por chat com o conteúdo integral do Novo - playbook.pdf no contexto da IA. Inclui 12 temas, geração de perfis variados nas 27 UFs, duas posturas de abertura, orientação durante a conversa e avaliação com referências conferidas contra as páginas e mensagens. Personagens fictícios; sem nota oficial, fine-tuning ou promessa de resposta infalível.

## Antes de publicar

Este pacote exige Netlify Functions. NÃO publique com Netlify Drop. NÃO escolha private-site como pasta pública. A pasta de publicação correta é publish. O conteúdo compilado em private-site é incluído dentro da função access, que exige senha antes de servir páginas, arquivos e APIs. A pasta publish contém apenas um aviso seguro caso o servidor não tenha sido instalado.

A versão foi compilada e testada localmente, com chamadas de IA substituídas por fixtures de integração. Não houve acesso à sua conta Netlify nem chamada com uma chave Gemini real. Será necessário confirmar o funcionamento na hospedagem após configurar as variáveis.

## 1. Prepare o Gemini

1. Acesse https://aistudio.google.com/apikey e selecione o projeto Google do simulador.
2. Crie ou confira sua chave Gemini API. Prefira uma chave nova criada no Google AI Studio; as chaves novas recebem a configuração de autorização do serviço. Uma chave antiga bloqueada, revogada ou com restrições incompatíveis pode ser recusada.
3. Confira se a Gemini API está habilitada e se o projeto tem acesso ao modelo escolhido, cota e faturamento necessários conforme sua conta. Este pacote não garante uso gratuito ou cota ilimitada.
4. Copie a chave diretamente para GEMINI_API_KEY no painel da Netlify. Não envie por chat, não coloque no GitHub nem em arquivos públicos.
5. O padrão é gemini-3.8-flash, modelo estável indicado na documentação consultada. Para usar outro modelo de texto com saída JSON estruturada, informe seu identificador em GEMINI_MODEL, sem o prefixo models/. A disponibilidade depende do projeto Google. Modelos 2.5 têm acesso limitado para novos projetos segundo a documentação atual; não são o padrão deste pacote.

## Migração da versão OpenAI

Substitua os arquivos do projeto pelos deste ZIP, preservando a estrutura. Cadastre GEMINI_API_KEY e, se desejar, GEMINI_MODEL. As antigas OPENAI_API_KEY e OPENAI_MODEL não são utilizadas por esta versão e podem ser removidas após confirmar a migração. Mantenha PLAYBOOK_PASSWORD e PLAYBOOK_COOKIE_KEY com os valores já configurados. Não apague o store cis-roleplay-profiles: ele conserva o registro de perfis e aberturas usados.

## 2. Publique pelo GitHub e painel da Netlify

1. Descompacte este ZIP. O projeto deve ter package.json e netlify.toml na raiz.
2. Crie um repositório PRIVADO no GitHub. Em Add file > Upload files, envie os arquivos e pastas descompactados mantendo sua estrutura. Não envie apenas o ZIP. Você não precisa de node_modules.
3. Na Netlify, Add new project > Import an existing project > GitHub. Autorize o repositório e selecione-o.
4. Confirme: base directory vazia; build command npm run build; publish directory publish. netlify.toml declara a função e os arquivos privados necessários. Use Node 22 compatível com engines do pacote (>=22.13).
5. Se fizer o primeiro deploy antes de cadastrar os segredos, o acesso permanecerá bloqueado. Isso é intencional.
6. Abra Project configuration > Environment variables > Add a variable > Add a single variable e configure os valores da seção abaixo.
7. Depois de salvar, vá a Deploys e solicite um novo deploy da versão atual. As alterações das variáveis precisam de nova publicação.
8. Abra Cloud compute > Functions e confirme a função access. Este pacote usa Functions, não Edge Functions.

## 3. Variáveis de ambiente

Cadastre no painel da Netlify. Marque as três primeiras como secret values quando a opção estiver disponível. Se houver seleção de escopo, inclua Functions; aplique os mesmos valores a todos os contextos de deploy que terão acesso ao simulador.

| Nome | Valor |
|---|---|
| GEMINI_API_KEY | SUA chave própria Gemini API criada no Google AI Studio, com acesso ao modelo e cota disponível |
| PLAYBOOK_PASSWORD | A senha de acesso indicada na conversa, ou outra senha forte escolhida por você |
| PLAYBOOK_COOKIE_KEY | A chave técnica aleatória indicada na conversa, ou outra com pelo menos 32 caracteres |
| GEMINI_MODEL | Opcional: gemini-3.8-flash; esse já é o padrão do código |

Não use prefixo VITE_ em nenhum segredo. Não coloque valores secretos em netlify.toml, index.html ou arquivos públicos. A chave Gemini é usada apenas pela função no servidor. A chave técnica assina o cookie de acesso e criptografa a sessão de treino; não é a senha que os usuários devem digitar.

Para gerar sua própria chave técnica, execute em um computador com Node:

```sh
node -e "process.stdout.write(require('crypto').randomBytes(48).toString('hex'))"
```

A senha compartilhada pode ser repassada por quem a conhece. O cookie vale 24 horas, HttpOnly, Secure em HTTPS e SameSite=Lax. Sair encerra o acesso neste navegador. Para revogar todas as sessões, troque senha E chave técnica e publique novamente.

## Alternativa: publicar pelo terminal

Instale Node compatível (>=22.13), abra o terminal dentro da pasta descompactada e execute:

```sh
npm install
npx netlify-cli login
npx netlify-cli link
npx netlify-cli deploy --build --prod
```

link deve apontar para um projeto já criado na sua conta Netlify. Cadastre as variáveis no painel ANTES do deploy final. Não coloque segredos em comandos, histórico do terminal ou repositório. Em caso de dúvida, prefira o fluxo GitHub acima.

## 4. Confira antes de usar

1. Abra o endereço publicado em uma janela anônima: a senha deve ser solicitada.
2. Digite uma senha incorreta e confirme que o acesso é negado.
3. Digite a senha correta. Após conferir /api/status, Gerar lead e iniciar deve estar disponível se GEMINI_API_KEY foi configurada. Esse status verifica a presença da chave, não sua validade/crédito.
4. Use Surpreenda-me ou selecione um tema, gere um lead e formule uma pergunta aberta com as palavras da fala inicial. Confira o nome e a cidade/UF do personagem.
5. Confira uma resposta dinâmica do lead. Peça orientação e, depois, encerre e avalie. As referências devem trazer páginas e trechos do playbook. Gere outros leads e confira a mudança de perfil, dor e desejo ao conduzir as conversas.
6. Teste Sair. Em janela anônima, /api/roleplay e um arquivo /assets/*.js também devem exigir acesso.
7. Confira em celular e desktop a leitura do chat, as caixas de texto e a avaliação.

## 5. Registro de perfis no Netlify Blobs

A função utiliza o armazenamento nativo Netlify Blobs, store cis-roleplay-profiles. Na execução em Netlify Functions, a plataforma fornece automaticamente as credenciais de acesso; não cadastre uma chave adicional no navegador. Confira a disponibilidade na sua conta e, após gerar o primeiro lead, veja Data & Storage > Blobs. O registro aparece na primeira utilização.

O contador é compartilhado por todo o projeto, permanece nos novos deploys e utiliza leitura forte e escrita condicional para reservar perfis distintos mesmo com acessos simultâneos. Não apague o store nem o contador: isso reiniciaria a sequência e permitiria reutilizar perfis. Uma cópia do site em outro projeto terá registro independente. Falhas de geração podem consumir uma posição sem abrir um treino.

A geração combina nome, cidade/UF, faixa de idade, setor, contexto, dor, desejo e emoção. O banco v1 possui 17.915.904 combinações por tema; a sequência global está limitada a esse número de reservas e, ao chegar ao limite, bloqueia novos treinos até ampliar o banco. Cidades, temas e componentes individuais reaparecem em combinações diferentes. Não existe garantia de variedade infinita nem de ausência de semelhança semântica entre todas as respostas da IA.

O sistema recusa uma fala inicial idêntica após normalizar caixa, espaços e pontuação; tenta uma nova formulação uma vez e, se ainda repetida, pede para gerar outro lead. O perfil completo não é enviado à interface: dor, desejo e emoção devem ser descobertos pela conversa. Uma sessão criptografada e vinculada ao acesso conserva o personagem entre as respostas e expira em 24 horas.

Os detalhes dos perfis são ficcionais para treino. Não substituem o playbook nem são novos casos ou regras oficiais do Método CIS. Para uma troca automática de temas, mantenha Surpreenda-me. Ao escolher um tema específico, novas combinações são geradas dentro dele.

## Solução de problemas

- Publicação incompleta: servidor não instalado ou pasta publicada errada. Use Git/CLI, mantenha netlify.toml e publish como pasta pública.
- Acesso sendo configurado (503): PLAYBOOK_PASSWORD ou PLAYBOOK_COOKIE_KEY ausentes/incorretas. Chave técnica precisa de 32 caracteres no mínimo. Refaça o deploy.
- IA aguardando ativação: GEMINI_API_KEY não foi configurada para Functions naquele deploy. Cadastre e publique novamente.
- Conexão de IA precisa ser revisada: chave inválida/revogada, projeto ou permissão de modelo incorretos. Use sua chave própria Gemini API, compatível com chamadas no servidor. A chave não deve estar bloqueada ou limitada apenas a referências HTTP de um navegador. Chaves de outros provedores não funcionam neste pacote.
- Serviço ocupado/sem crédito: verifique cotas e faturamento do projeto Google AI Studio. O código retorna uma mensagem segura e preserva seu texto; não exibe detalhes ou segredos do provedor.
- Formato ou referência não passou na conferência: a IA gerou uma citação incompatível. Tente novamente; a aplicação não apresenta a referência inventada como válida.
- Página não encontrada depois de entrar: confirme build concluído e included_files = ["private-site/**"] em netlify.toml. Não mova as pastas.
- Não foi possível registrar um perfil: confira Netlify Blobs e a execução da função access. O treino não inicia com um perfil local reutilizado quando o registro está indisponível.
- Treino expirado ou inválido: encerre e prepare um novo lead. Mudanças da chave técnica invalidam sessões antigas.
- Modelo inválido/indisponível: confira GEMINI_MODEL e a disponibilidade do modelo no projeto Google. O identificador deve ser de um modelo de texto com JSON estruturado.
- Configuração rejeitada: confira o modelo e publique todos os arquivos da mesma versão.
- Resposta bloqueada: o Gemini aplicou uma restrição à geração; use cenários fictícios e reformule sem dados sensíveis.
- Logs: use Cloud compute > Functions > access para verificar erros de execução. Não compartilhe chaves ou dados pessoais em capturas dos logs.

## Dados, limites e fidelidade

A conversa fica na memória da página, até recarregar ou trocar o cenário. Sem histórico permanente das conversas. O Netlify Blobs mantém um contador de perfis utilizados e hashes das falas iniciais, sem mensagens do consultor. Até 24 respostas por conversa e 2.000 caracteres por mensagem. Há limitação preventiva por IP/sessão/instância; ela não substitui limite financeiro global do provedor.

O corpus e as mensagens são enviados à Google Gemini API para inferência quando a IA está conectada. A aplicação não mantém um histórico permanente das conversas no servidor. O tratamento de dados pelo Google depende dos termos e da modalidade da sua conta; não há promessa de retenção zero. Use cenários fictícios, não informações pessoais de leads reais.

Os dados comerciais do PDF são snapshot Goiânia 252, validado em 07/10/2026. Reconfirme antes de usar em vendas reais. O prazo da garantia contém divergência e não deve ser informado sem confirmação. A IA não deve prometer cura, resultado, escassez ou depoimentos inventados. A conferência de trechos não garante que a interpretação da IA esteja correta.

## Referências oficiais de configuração

- https://docs.netlify.com/build/functions/configuration/
- https://docs.netlify.com/build/functions/environment-variables/
- https://docs.netlify.com/api-and-cli-guides/cli-guides/get-started-with-cli/
- https://ai.google.dev/gemini-api/docs/api-key
- https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash
- https://ai.google.dev/api/generate-content
- https://ai.google.dev/gemini-api/docs/structured-output

- https://docs.netlify.com/build/data-and-storage/netlify-blobs/

## Revisão desta versão

Consulte REVISAO.md para os testes concluídos e os pontos que exigem validação após publicar. O navegador de prévia não ficou acessível neste ambiente; por isso, esta revisão não certifica testes visuais em aparelhos físicos ou em todos os navegadores.
